//package com.example.chat.controller;
//
//public class PublicChatController {
//}


package com.example.chat.controller;

import com.example.chat.dto.ChatMessageDTO;
import com.example.chat.entity.ChatRoom;
import com.example.chat.entity.User;
import com.example.chat.service.ChatService;
import com.example.chat.service.MessageService;
import com.example.chat.service.UserService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.stereotype.Controller;

import java.time.Instant;

@Controller
public class PublicChatController {

    private final UserService userService;
    private final ChatService chatService;
    private final MessageService messageService;

    public PublicChatController(UserService userService,
                                ChatService chatService,
                                MessageService messageService) {
        this.userService = userService;
        this.chatService = chatService;
        this.messageService = messageService;
    }

    // Client sends to /app/chat.sendMessage
    @MessageMapping("/chat.sendMessage")
    @SendTo("/topic/public")
    public ChatMessageDTO sendMessage(ChatMessageDTO dto, SimpMessageHeaderAccessor headerAccessor) {

        String username = (String) headerAccessor.getSessionAttributes().get("username");
        if (username == null) {
            throw new RuntimeException("User not registered in WebSocket session");
        }

        User sender = userService.findByUsername(username);
        ChatRoom room = chatService.findOrCreateRoom(dto.getRoomName(), false);

        // Save message in DB
        messageService.saveMessage(room, sender, dto.getContent());

        // Return DTO to broadcast
        dto.setFrom(username);
        dto.setTimestamp(Instant.now());
        return dto;
    }
}
