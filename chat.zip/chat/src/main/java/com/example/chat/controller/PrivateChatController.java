//package com.example.chat.controller;
//
//public class PrivateChatController {
//}


package com.example.chat.controller;

import com.example.chat.dto.PrivateChatMessageDTO;
import com.example.chat.entity.User;
import com.example.chat.service.MessageService;
import com.example.chat.service.UserService;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.simp.SimpMessageHeaderAccessor;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.stereotype.Controller;

import java.time.Instant;

@Controller
public class PrivateChatController {

    private final SimpMessagingTemplate messagingTemplate;
    private final UserService userService;
    private final MessageService messageService;

    public PrivateChatController(SimpMessagingTemplate messagingTemplate,
                                 UserService userService,
                                 MessageService messageService) {
        this.messagingTemplate = messagingTemplate;
        this.userService = userService;
        this.messageService = messageService;
    }

    // Client sends to /app/chat.privateMessage
    @MessageMapping("/chat.privateMessage")
    public void sendPrivateMessage(PrivateChatMessageDTO dto, SimpMessageHeaderAccessor headerAccessor) {
        String senderUsername = (String) headerAccessor.getSessionAttributes().get("username");
        if (senderUsername == null) {
            throw new RuntimeException("WebSocket session not registered with username");
        }

        User sender = userService.findByUsername(senderUsername);
        User recipient = userService.findByUsername(dto.getTo());

        if (recipient == null) {
            throw new RuntimeException("Recipient not found: " + dto.getTo());
        }

        // Set DTO metadata
        dto.setFrom(senderUsername);
        dto.setTimestamp(Instant.now());

        // Save private message in DB (chatRoom = null)
        messageService.saveMessage(null, sender, dto.getContent());

        // Send to recipient's private queue
        messagingTemplate.convertAndSendToUser(
                recipient.getUsername(),
                "/queue/messages",
                dto
        );
    }
}
