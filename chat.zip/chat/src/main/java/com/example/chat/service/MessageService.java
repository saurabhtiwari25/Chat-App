//package com.example.chat.service;
//
//public class MessageService {
//}

package com.example.chat.service;

import com.example.chat.entity.Message;
import com.example.chat.entity.User;
import com.example.chat.entity.ChatRoom;
import com.example.chat.repository.MessageRepository;
import org.springframework.stereotype.Service;

import java.time.Instant;

@Service
public class MessageService {
    private final MessageRepository messageRepository;

    public MessageService(MessageRepository messageRepository) {
        this.messageRepository = messageRepository;
    }

    // Save public message
    public Message saveMessage(ChatRoom chatRoom, User sender, String content) {
        Message message = Message.builder()
                .chatRoom(chatRoom)
                .sender(sender)
                .content(content)
                .timestamp(Instant.now())
                .build();
        return messageRepository.save(message);
    }
}

