//package com.example.chat.service;
//
//public class ChatService {
//}


package com.example.chat.service;

import com.example.chat.entity.ChatRoom;
import com.example.chat.repository.ChatRoomRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ChatService {

    private final ChatRoomRepository chatRoomRepository;

    public ChatService(ChatRoomRepository chatRoomRepository) {
        this.chatRoomRepository = chatRoomRepository;
    }

    // Find existing room or create if it doesn't exist
    public ChatRoom findOrCreateRoom(String roomName, boolean isPrivate) {
        Optional<ChatRoom> roomOpt = chatRoomRepository.findByName(roomName);
        if (roomOpt.isPresent()) {
            return roomOpt.get();
        }

        ChatRoom room = ChatRoom.builder()
                .name(roomName)
                .isPrivate(isPrivate)
                .build();
        return chatRoomRepository.save(room);
    }
}
