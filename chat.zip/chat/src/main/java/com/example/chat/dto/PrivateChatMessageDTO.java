//package com.example.chat.dto;
//
//public class PrivateChatMessageDTO {
//}


package com.example.chat.dto;

import lombok.*;
import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PrivateChatMessageDTO {
    private String from;
    private String to;
    private String content;
    private Instant timestamp;
}
