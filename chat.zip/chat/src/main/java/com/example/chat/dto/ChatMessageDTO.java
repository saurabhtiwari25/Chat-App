//package com.example.chat.dto;
//
//public class ChatMessageDTO {
//}


package com.example.chat.dto;

import lombok.*;
import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChatMessageDTO {
    private String from;
    private String content;
    private Instant timestamp;
    private String roomName;
}
