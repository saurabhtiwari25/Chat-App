//package com.example.chat.entity;
//
//public class User {
//}


package com.example.chat.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false)
    private String username;

    // Optional: List of messages sent
    @OneToMany(mappedBy = "sender", cascade = CascadeType.ALL)
    private List<Message> messages;
}
